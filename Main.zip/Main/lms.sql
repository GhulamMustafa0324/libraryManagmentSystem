-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 03, 2021 at 05:24 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lms`
--

-- --------------------------------------------------------

--
-- Table structure for table `aboutbooks`
--

CREATE TABLE `aboutbooks` (
  `s.no` int(255) NOT NULL,
  `BookID` varchar(255) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `publisher` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `publish_year` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `aboutbooks`
--

INSERT INTO `aboutbooks` (`s.no`, `BookID`, `Name`, `publisher`, `price`, `publish_year`) VALUES
(1, '12', 'maths', 'mustafa', '55', '2020'),
(2, '1', '12', '11', '12', '12');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `s.no` int(255) NOT NULL,
  `Book_ID` int(255) NOT NULL,
  `book_name` varchar(255) NOT NULL,
  `author_name` varchar(255) NOT NULL,
  `publish_year` int(255) NOT NULL,
  `category` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`s.no`, `Book_ID`, `book_name`, `author_name`, `publish_year`, `category`) VALUES
(14, 123, 'subconcious', 'mustafa', 2021, 'novel'),
(15, 1234, 'hardwork', 'mustafa', 2021, 'novel');

-- --------------------------------------------------------

--
-- Table structure for table `issuebook`
--

CREATE TABLE `issuebook` (
  `s.no` int(255) NOT NULL,
  `BookID` varchar(255) NOT NULL,
  `StudentID` varchar(255) NOT NULL,
  `issueDate` varchar(255) NOT NULL,
  `dueDate` varchar(255) NOT NULL,
  `returnBook` varchar(255) NOT NULL DEFAULT 'Not Returned Yet'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `issuebook`
--

INSERT INTO `issuebook` (`s.no`, `BookID`, `StudentID`, `issueDate`, `dueDate`, `returnBook`) VALUES
(1, '12', '030', '123', '123', 'Not Returned Yet'),
(3, '1234', '030', '123', '123', 'Not Returned Yet');

-- --------------------------------------------------------

--
-- Table structure for table `seatbooking`
--

CREATE TABLE `seatbooking` (
  `student_id` varchar(255) NOT NULL,
  `computer_no` varchar(255) NOT NULL,
  `book_id` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `time` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seatbooking`
--

INSERT INTO `seatbooking` (`student_id`, `computer_no`, `book_id`, `department`, `time`) VALUES
('002', '2', '1234', 'BSCS', '12:30-1'),
('1', '1', '1', 'BSCS', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `s.no` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `ID` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`s.no`, `name`, `password`, `ID`) VALUES
(1, 'Irfan Ali', 'Smiu', '049'),
(2, 'ansa', '55555', '090'),
(3, 'aiira', '111', '002'),
(4, 'irfan', '22', '1'),
(6, 'aaira', '123', '12'),
(7, 'ansa zakir', '222', '34');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `s.no` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `id` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `mobile_no` varchar(255) NOT NULL,
  `gender` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`s.no`, `name`, `f_name`, `id`, `department`, `mobile_no`, `gender`) VALUES
(8, 'ansa', 'zakir', '030', 'cs', '032222', 'Other'),
(9, 'mustafa', 'm.ali', '049', 'bscs', '123', 'Male');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aboutbooks`
--
ALTER TABLE `aboutbooks`
  ADD PRIMARY KEY (`s.no`),
  ADD UNIQUE KEY `Book_ID` (`BookID`,`Name`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`s.no`),
  ADD UNIQUE KEY `book_name` (`book_name`),
  ADD UNIQUE KEY `Book_ID` (`Book_ID`);

--
-- Indexes for table `issuebook`
--
ALTER TABLE `issuebook`
  ADD PRIMARY KEY (`s.no`);

--
-- Indexes for table `seatbooking`
--
ALTER TABLE `seatbooking`
  ADD UNIQUE KEY `student_id` (`student_id`,`book_id`),
  ADD UNIQUE KEY `computer_no` (`computer_no`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`s.no`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`s.no`),
  ADD UNIQUE KEY `id` (`id`,`mobile_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aboutbooks`
--
ALTER TABLE `aboutbooks`
  MODIFY `s.no` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `s.no` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `issuebook`
--
ALTER TABLE `issuebook`
  MODIFY `s.no` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `s.no` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `s.no` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
